// Simplified DashboardPage.tsx with Supabase and editable profile
"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://YOUR-SUPABASE-URL.supabase.co"
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "YOUR_ANON_KEY"

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Supabase environment variables are missing. Please set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.")
}

const supabase = createClient(supabaseUrl, supabaseAnonKey)

export default function DashboardPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState({
    first_name: "",
    last_name: "",
    occupation: "",
    bio: "",
  })
  const [isEditing, setIsEditing] = useState(false)

  useEffect(() => {
    const loadUser = async () => {
      const { data, error } = await supabase.auth.getUser()
      if (!data?.user || error) return router.push("/auth/login")
      setUser(data.user)

      const { data: p } = await supabase.from("profiles").select("first_name, last_name, occupation, bio").eq("id", data.user.id).single()

      if (p) {
        setProfile(p)
      } else {
        await supabase.from("profiles").insert({
          id: data.user.id,
          first_name: "",
          last_name: "",
          occupation: "",
          bio: "",
        })
      }

      setLoading(false)
    }
    loadUser()
  }, [router])

  const handleChange = (e) => {
    const { name, value } = e.target
    setProfile((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    await supabase.from("profiles").upsert({ id: user.id, ...profile })
    setIsEditing(false)
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  if (loading) return <p className="text-center py-10">Loading...</p>

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow px-4 py-4">
        <h1 className="text-xl font-bold">Equity Route</h1>
      </header>
      <main className="flex-grow p-6 bg-gray-50">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold mb-4">Welcome, {user?.email}</h1>

          {isEditing ? (
            <form onSubmit={handleSubmit} className="space-y-4 mb-6">
              <label className="block font-medium">First Name</label>
              <input name="first_name" value={profile.first_name} onChange={handleChange} required className="w-full border border-gray-300 rounded-md px-3 py-2" />
              <label className="block font-medium">Last Name</label>
              <input name="last_name" value={profile.last_name} onChange={handleChange} required className="w-full border border-gray-300 rounded-md px-3 py-2" />
              <label className="block font-medium">Occupation</label>
              <select name="occupation" value={profile.occupation} onChange={handleChange} className="w-full border border-gray-300 rounded-md px-3 py-2">
                <option value="">Select your role</option>
                <option value="Investor">Property Investor</option>
                <option value="Agent">Real Estate Agent</option>
                <option value="Broker">Mortgage Broker</option>
                <option value="Developer">Property Developer</option>
                <option value="Manager">Property Manager</option>
                <option value="Accountant">Accountant</option>
                <option value="Other">Other</option>
              </select>
              <label className="block font-medium">Bio</label>
              <textarea name="bio" rows={3} className="w-full border border-gray-300 rounded-md px-3 py-2" value={profile.bio} onChange={handleChange}></textarea>
              <div className="flex gap-2">
                <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
                <button type="button" className="border border-gray-400 px-4 py-2 rounded" onClick={() => setIsEditing(false)}>Cancel</button>
              </div>
            </form>
          ) : (
            <div className="mb-6 space-y-2">
              <p><strong>Name:</strong> {profile.first_name} {profile.last_name}</p>
              <p><strong>Occupation:</strong> {profile.occupation}</p>
              <p><strong>Bio:</strong> {profile.bio}</p>
              <button className="mt-2 bg-blue-600 text-white px-4 py-2 rounded" onClick={() => setIsEditing(true)}>Edit Profile</button>
            </div>
          )}

          <button onClick={handleLogout} className="mt-4 border border-gray-400 px-4 py-2 rounded">Log Out</button>
        </div>
      </main>
      <footer className="bg-white shadow px-4 py-4 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Equity Route. All rights reserved.
      </footer>
    </div>
  )
}
